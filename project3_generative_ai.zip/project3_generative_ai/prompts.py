SUMMARY_PROMPT = """You are an AI assistant for data analysts and public-sector decision-makers.

Task:
Summarize the text into a structured JSON-like format with:
- key_insights: 3–6 bullet points
- risks: 2–5 bullet points
- recommendations: 3–6 bullet points
- one_sentence_summary: 1 sentence

Text:
{content}
"""