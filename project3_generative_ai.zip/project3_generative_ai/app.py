import json
from pathlib import Path
from datetime import datetime
from prompts import SUMMARY_PROMPT


def generate_summary_offline(text: str) -> dict:
    """
    Offline, simulated GenAI summarizer.
    This keeps the project runnable without an API key and demonstrates structure + workflow.
    """
    # Example heuristic output (replace later with real LLM call if desired)
    summary = {
        "one_sentence_summary": "Generative AI can help decision-makers quickly extract insights from large volumes of analytical reports.",
        "key_insights": [
            "Large volumes of reports slow down decision-making.",
            "Summarization can convert long text into decision-ready insights.",
            "Structured outputs improve readability and usability.",
        ],
        "risks": [
            "Automated summaries may omit important context.",
            "Outputs require human validation for accuracy and bias.",
        ],
        "recommendations": [
            "Use GenAI as decision support, not a final authority.",
            "Validate summaries with domain experts before action.",
            "Standardize templates for consistent reporting across teams.",
        ],
        "metadata": {
            "mode": "offline_simulation",
            "prompt_used": "SUMMARY_PROMPT (template-based)",
            "prompt_preview": SUMMARY_PROMPT.format(content=text[:200] + ("..." if len(text) > 200 else "")),
        },
    }
    return summary


def save_summary(summary: dict, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = output_dir / f"summary_{timestamp}.json"
    out_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return out_path


def main():
    input_path = Path("sample_input.txt")
    if not input_path.exists():
        raise FileNotFoundError("sample_input.txt not found. Create it and add text to summarize.")

    text = input_path.read_text(encoding="utf-8").strip()
    if not text:
        raise ValueError("sample_input.txt is empty. Add some text to summarize.")

    summary = generate_summary_offline(text)

    print("\n=== ONE-SENTENCE SUMMARY ===")
    print(summary["one_sentence_summary"])

    print("\n=== KEY INSIGHTS ===")
    for i, item in enumerate(summary["key_insights"], 1):
        print(f"{i}. {item}")

    print("\n=== RISKS ===")
    for i, item in enumerate(summary["risks"], 1):
        print(f"{i}. {item}")

    print("\n=== RECOMMENDATIONS ===")
    for i, item in enumerate(summary["recommendations"], 1):
        print(f"{i}. {item}")

    out_path = save_summary(summary, Path("outputs/summaries"))
    print(f"\nSaved summary to: {out_path}")


if __name__ == "__main__":
    main()